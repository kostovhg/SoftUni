package org.softuni.ruk.utils;

public class Messages {

    public static final String INCORRECT_DATA_ERROR = "Error: Incorrect Data!";

    public static final String SUCCESS_FORMAT = "Succesfully imported %s – %s.";
}
