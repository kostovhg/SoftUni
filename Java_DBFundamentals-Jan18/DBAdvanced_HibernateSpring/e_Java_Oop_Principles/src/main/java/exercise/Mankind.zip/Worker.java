package exercise.g_Mankind;

public class Worker extends Human {

    public static final String INVALID_WEEK_SALARY = "Expected value mismatch!Argument: weekSalary";
    public static final String INVALID_WORK_HOURS_PER_DAY = "Expected value mismatch!Argument: workHoursPerDay";
    public static final String INVALID_LAST_NAME_LENGTH = "Expected length more than 3 symbols!Argument: lastName";
    private double weekSalary;
    private double workHoursPerDay;

    public Worker(String[] args) {
        super(args[0], args[1]);
        this.setWeekSalary(args[2]);
        this.setWorkingHours(args[3]);
    }

    private void setWeekSalary(String weekSalary) {
        double decimalSalary = Double.parseDouble(weekSalary);
        if (decimalSalary < 10) {
            throw new IllegalArgumentException(INVALID_WEEK_SALARY);
        }
        this.weekSalary = decimalSalary;
    }

    private void setWorkingHours(String workingHours) {
        double hours = Double.parseDouble(workingHours);
        if (hours < 1.0 || hours > 12.0) {
            throw new IllegalArgumentException(INVALID_WORK_HOURS_PER_DAY);
        }
        this.workHoursPerDay = hours;
    }

    private Double getSalaryPerHour() {
        return this.weekSalary / this.workHoursPerDay / 7.0;
    }

    @Override
    protected void setLastName(String lastName) {
        if(lastName == null || lastName.trim().length() < 4) {
            throw new IllegalArgumentException(INVALID_LAST_NAME_LENGTH);
        }
        super.setLastName(lastName);
    }

    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.toString())
                .append("Week Salary: ").append(this.weekSalary)
                .append(System.lineSeparator())
                .append("Hours per day: ").append(this.workHoursPerDay)
                .append(System.lineSeparator())
                .append("Salary per hour: ")
                .append(String.format("%.2f", this.getSalaryPerHour()))
                .append(System.lineSeparator());

        return sb.toString();
    }
}
