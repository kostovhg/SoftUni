package exercise.g_Mankind;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    private static final String DELIMITER = "\\s+";

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Human student = null;
        Human worker = null;

        try {
            student = new Student(reader.readLine().split(DELIMITER));
            worker = new Worker(reader.readLine().split(DELIMITER));
            System.out.println(student);
            System.out.println(worker.toString().trim());
        } catch (IllegalArgumentException iae){
            System.out.println(iae.getMessage());
        }
    }
}