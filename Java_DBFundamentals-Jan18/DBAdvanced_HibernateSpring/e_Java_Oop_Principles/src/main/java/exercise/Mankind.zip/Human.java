package exercise.g_Mankind;

public abstract class Human {

    private static final String INVALID_FIRST_NAME_LETTER = "Expected upper case letter!Argument: firstName";
    private static final String INVALID_FIRST_NAME_LENGTH = "Expected length at least 4 symbols!Argument: firstName";
    private static final String INVALID_LAST_NAME_FIRST_LETTER = "Expected upper case letter!Argument: lastName";
    public static final String INVALID_LAST_NAME_LENGTH = "Expected length at least 3 symbols!Argument: lastName";
    private String firstName;
    private String lastName;

    public Human(String firstName, String lastName) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
    }

    protected void setFirstName(String firstName) {
        if (this.firstName == null || firstName.trim().length() < 4) {
            throw new IllegalArgumentException(INVALID_FIRST_NAME_LENGTH);
        }
        if (Character.isLowerCase(firstName.charAt(0))){
            throw new IllegalArgumentException(INVALID_FIRST_NAME_LETTER);
        }
        this.firstName = firstName.trim();
    }

    protected void setLastName(String lastName) {
        if (lastName == null || lastName.trim().length() < 3) {
            throw new IllegalArgumentException(INVALID_LAST_NAME_LENGTH);
        }
        if (Character.isLowerCase(lastName.charAt(0))){
            throw new IllegalArgumentException(INVALID_LAST_NAME_FIRST_LETTER);
        }
        this.lastName = lastName.trim();
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();

        sb.append("First Name: ");
        sb.append(this.getFirstName());
        sb.append(System.lineSeparator());
        sb.append("Last Name: ");
        sb.append(this.getLastName());
        sb.append(System.lineSeparator());

        return sb.toString();
    }
}
