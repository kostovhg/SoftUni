package exercise.b_MultipleImplementation;

public interface Birthable {

    String getBirthdate();
}
