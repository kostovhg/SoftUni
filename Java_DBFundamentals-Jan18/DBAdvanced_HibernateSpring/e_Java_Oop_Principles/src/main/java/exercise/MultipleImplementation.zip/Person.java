package exercise.b_MultipleImplementation;

public interface Person {

    String getName();

    int getAge();
}
