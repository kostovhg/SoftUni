package exercise.b_MultipleImplementation;

public interface Identifiable {

    String getId();
}
