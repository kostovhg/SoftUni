package exercise.a_DefineAnIntefacePerson;

public interface Person {

    String getName();

    int getAge();
}
