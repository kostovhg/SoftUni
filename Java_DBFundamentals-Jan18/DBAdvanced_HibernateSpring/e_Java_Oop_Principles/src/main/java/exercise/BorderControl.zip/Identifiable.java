package exercise.e_BorderControl;

public interface Identifiable {

    String getId();

    boolean validateID(String id);
}
