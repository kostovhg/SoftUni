package exercise.c_Ferrari;

public interface Car {

    String brakes();

    String gasPedal();
}
