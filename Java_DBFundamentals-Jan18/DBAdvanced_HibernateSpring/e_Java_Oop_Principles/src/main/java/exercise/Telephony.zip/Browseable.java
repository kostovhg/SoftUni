package exercise.d_Telephony;

public interface Browseable {

    String browse(String address);
}
