package exercise.d_Telephony;

public interface Callable {

    String call(String phoneNumber);
}
