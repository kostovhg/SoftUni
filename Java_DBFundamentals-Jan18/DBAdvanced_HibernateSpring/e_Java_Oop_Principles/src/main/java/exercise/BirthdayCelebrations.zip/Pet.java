package exercise.f_BirthdayCelebrations;

public class Pet extends BaseBeing {

    public Pet(String[] args) {
        super(args[1], args[2]);
    }

}
