package exercise.f_BirthdayCelebrations;

public interface Born {

    String getBirthday();

    boolean validateBirthYear(String year);
}
