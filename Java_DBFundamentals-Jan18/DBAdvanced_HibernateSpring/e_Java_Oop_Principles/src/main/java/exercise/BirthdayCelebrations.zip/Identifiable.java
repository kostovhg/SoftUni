package exercise.f_BirthdayCelebrations;

public interface Identifiable {

    String getId();

}
