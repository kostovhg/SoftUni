package pawInc.entities.centers;

import pawInc.entities.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public class CleansingCenter extends Center {

    public CleansingCenter(String name) {
        super(name);
    }

    public List<Animal> cleansing(){
        List<Animal> cleansedAnimals = new ArrayList<>();
        super.getStoredAnimals().forEach(Animal::cleanse);
        cleansedAnimals.addAll(super.getStoredAnimals());
        super.removeAll(cleansedAnimals);
        return cleansedAnimals;
    }
}
