package a_ListyIterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListIterator {

    private List<String> theList;
    private int index;

    public ListIterator(String... someList) {
        this.setTheList(someList);
        this.index = 0;
    }

    private void setTheList(String... theList) {
        if(theList.length == 0){
            this.theList = new ArrayList<>();
        } else {
            this.theList = new ArrayList<>(Arrays.asList(theList));
        }
    }

    public boolean move(){
        if(hasNext()) {
            index++;
            return true;
        }
        else return false;
    }

    public boolean hasNext(){
        return this.theList.size() > index + 1;
    }

    public void print(){
        try{
            System.out.println(this.theList.get(index));
        } catch (IndexOutOfBoundsException ioobe) {
            System.out.println("Invalid Operation!");
        }
    }
}
