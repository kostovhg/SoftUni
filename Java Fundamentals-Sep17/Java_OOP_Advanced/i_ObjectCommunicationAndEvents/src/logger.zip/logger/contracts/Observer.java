package logger.contracts;

public interface Observer {

    void update( int value);
}
