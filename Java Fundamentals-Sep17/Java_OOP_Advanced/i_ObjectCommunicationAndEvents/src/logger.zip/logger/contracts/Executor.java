package logger.contracts;

public interface Executor {

    void executeCommand(Command command);

}
