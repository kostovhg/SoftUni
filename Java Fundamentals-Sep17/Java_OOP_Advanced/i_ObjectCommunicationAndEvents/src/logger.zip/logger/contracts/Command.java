package logger.contracts;

public interface Command {

    void execute();

}
