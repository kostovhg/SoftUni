function increment(selector) {
    // TODO: 
}
