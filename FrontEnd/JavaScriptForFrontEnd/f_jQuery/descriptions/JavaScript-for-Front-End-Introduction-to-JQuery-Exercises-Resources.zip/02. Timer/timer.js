function timer() {
   // TODO:
}