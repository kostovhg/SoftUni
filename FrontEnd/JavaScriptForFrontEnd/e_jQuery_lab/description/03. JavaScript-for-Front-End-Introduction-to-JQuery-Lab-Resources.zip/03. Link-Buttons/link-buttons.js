function attachEvents() {
   // TODO:
}